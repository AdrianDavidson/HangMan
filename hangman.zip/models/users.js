let mongoose = require('mongoose');

//schema
let userSchema = mongoose.Schema({
  Firstname:{
    type: String,
    required: true
  },
  Lastname:{
    type: String,
    required: true
  }
});

let Users = module.exports = mongoose.model('User', userSchema);
