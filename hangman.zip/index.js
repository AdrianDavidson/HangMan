
// GO TO LOCAL HOST 3001 SEE THE ERROR TRY fix
// https://www.youtube.com/watch?v=cVYQEvP-_PA&list=PLillGF-RfqbYRpji8t4SxUkMxfowG4Kqp&index=4 

const express = require('express');
const path = require('path');
const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost/Users');
let db = mongoose.connection;

// check connection
db.once('open', function(){
  console.log('Connected to MongoDB!');
});

//check for any db errors
db.on('error', function(err){
  console.log(err);
});

// initialise the app
const app = express();

// bring in models
let User = require('./models/users');

app.get('/', function(req, res){
  user.find({}, function(err, users){
    if(err){
      console.log(err);
    }
    else{
      res.render('index', {
        Firstname: users,
        Lastname: users
      });
    }
  });
});


// Port
app.listen(3001, function(){
  console.log('Server started on port 3001!')
});
